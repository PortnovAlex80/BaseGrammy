# Определённые артикли во всех падежах

**Правило:** Определённые артикли склоняются по падежам: Nom. der/die/das/die, Akk. den/die/das/die, Dat. dem/der/dem/den, Gen. des/der/des/der.

## Примеры
{de}Der Hund sieht den Mann. (Nom + Akk){/de}
{de}Ich gebe dem Kind das Buch. (Dat + Akk){/de}

## Перевод
Собака видит мужчину. (Им. + Вин.)
Я даю ребёнку книгу. (Дат. + Вин.)
