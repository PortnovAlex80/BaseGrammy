# Спряжение глагола haben (иметь)

**Правило:** Неправильный глагол haben спрягается: ich habe, du hast, er/sie/es hat, wir haben, ihr habt, sie/Sie haben.

## Примеры
{de}Ich habe Zeit.{/de}
{de}Er hat einen Hund.{/de}

## Перевод
У меня есть время.
У него есть собака.
