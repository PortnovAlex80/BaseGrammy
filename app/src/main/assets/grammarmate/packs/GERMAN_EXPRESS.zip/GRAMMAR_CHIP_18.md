# Модальные глаголы: dürfen, sollen, möchten

**Правило:** dürfen (разрешение), sollen (долженствование по чужой воле), möchten (желание). Спряжение как у других модальных: ich darf, soll, möchte.

## Примеры
{de}Sie dürfen hier rauchen.{/de}
{de}Ich möchte einen Kaffee.{/de}

## Перевод
Вам разрешено здесь курить.
Я бы хотел кофе.
