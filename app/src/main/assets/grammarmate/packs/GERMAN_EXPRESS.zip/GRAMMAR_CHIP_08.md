# Притяжательные артикли

**Правило:** Притяжательные артикли: mein (мой), dein (твой), sein (его), ihr (её/их), unser (наш), euer (ваш). Склоняются как ein/eine.

## Примеры
{de}Mein Bruder wohnt in Berlin.{/de}
{de}Ich sehe deinen Hund.{/de}

## Перевод
Мой брат живёт в Берлине.
Я вижу твою собаку.
