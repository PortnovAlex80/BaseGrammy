# Спряжение глагола sein (быть)

**Правило:** Неправильный глагол sein спрягается: ich bin, du bist, er/sie/es ist, wir sind, ihr seid, sie/Sie sind.

## Примеры
{de}Ich bin müde.{/de}
{de}Wir sind Studenten.{/de}

## Перевод
Я устал(а).
Мы студенты.
