# Личные местоимения

**Правило:** Личные местоимения заменяют существительные: ich, du, er, sie, es, wir, ihr, sie, Sie. В 3-м лице род зависит от существительного.

## Примеры
{de}Ich lerne Deutsch. Du sprichst gut.{/de}
{de}Er ist hier. Wir gehen nach Hause.{/de}

## Перевод
Я учу немецкий. Ты говоришь хорошо.
Он здесь. Мы идём домой.
