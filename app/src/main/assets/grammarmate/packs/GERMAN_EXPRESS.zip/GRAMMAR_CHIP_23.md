# Временные выражения

**Правило:** Время: um + часы (um 8 Uhr), am + день (am Montag), am + дата (am 1. Mai), im + месяц/сезон (im Januar, im Sommer), von... bis... (от... до...).

## Примеры
{de}Der Unterricht beginnt um 9 Uhr.{/de}
{de}Im Winter ist es kalt.{/de}

## Перевод
Занятия начинаются в 9 часов.
Зимой холодно.
