# Правильные глаголы на -eln / -ern

**Правило:** Глаголы на -eln и -ern сохраняют -e- в основе: handeln → ich handle, wandern → ich wandere. Окончания те же, что у обычных глаголов.

## Примеры
{de}Ich wandere gern in den Bergen.{/de}
{de}Es handelt sich um ein Problem.{/de}

## Перевод
Я люблю бродить по горам.
Речь идёт о проблеме.
