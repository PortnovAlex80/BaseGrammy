# Приставочные (разделяемые) глаголы

**Правило:** Приставка отделяется от глагола и уходит в конец предложения: anfangen → Ich fange an. Приставка ударная: ánfangen, áusgehen.

## Примеры
{de}Ich stehe um 7 Uhr auf.{/de}
{de}Wir räumen das Zimmer auf.{/de}

## Перевод
Я встаю в 7 часов (aufstehen).
Мы убираем комнату (aufräumen).
