# Правильные глаголы на -en

**Правило:** Правильные глаголы спрягаются по схеме: -e, -st, -t, -en, -t, -en. Основа глагола + окончание: ich lerne, du lernst, er lernt.

## Примеры
{de}Ich lerne Deutsch.{/de}
{de}Wir arbeiten viel.{/de}

## Перевод
Я учу немецкий.
Мы много работаем.
